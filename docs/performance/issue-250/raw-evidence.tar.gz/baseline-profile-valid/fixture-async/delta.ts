import { appendFileSync } from "node:fs";
import { performance } from "node:perf_hooks";
import { Type } from "typebox";
const record = type => appendFileSync(process.env.PI_PERF_EXTENSION_TRACE, JSON.stringify({type, name: "delta", at: performance.now()}) + "\n");
record("import:start");

await new Promise(resolve => setTimeout(resolve, 30));
record("import:end");
export default async function(pi) {
    record("factory:start");
    await new Promise(resolve => setTimeout(resolve, 2));
    pi.registerTool({name: "delta", label: "delta", description: "Synthetic tool", parameters: Type.Object({}), execute: async () => ({content: [{type: "text", text: "ok"}]})});
    pi.registerCommand("delta", { handler: async () => {} });
    pi.registerFlag("delta-flag", {type: "string", default: "delta"});
    record("factory:end");
}
