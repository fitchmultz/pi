import hashlib
import json
from pathlib import Path

result = {}
for side, root in [('before', Path('/workspace/pi-250-before')), ('after', Path('/workspace/pi-250'))]:
    files = {}
    for package in ['ai', 'agent', 'chord', 'codemode', 'durable', 'mcp', 'telemetry', 'tui', 'coding-agent']:
        for file in sorted((root / 'packages' / package / 'dist').rglob('*')):
            if file.is_file():
                files[str(file.relative_to(root))] = hashlib.sha256(file.read_bytes()).hexdigest()
    result[side] = {'files': files, 'mapSha256': hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()}
Path(__file__).with_name('build-trees.json').write_text(json.dumps(result, indent=2))
print({side: {'files': len(data['files']), 'mapSha256': data['mapSha256']} for side, data in result.items()})
