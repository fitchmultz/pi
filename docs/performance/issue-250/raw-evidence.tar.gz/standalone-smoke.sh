#!/usr/bin/env bash
set -euo pipefail
root=/workspace/evidence/issue-250/standalone-smoke
fixture=/workspace/evidence/issue-250/matched/fixture-async
cli=/workspace/evidence/issue-250/standalone/linux-x64/pi
mkdir -p "$root/home" "$root/agent" "$root/tmp"
if [[ -e "$root/imports.jsonl" ]]; then echo 'Refusing to overwrite retained imports' >&2; exit 1; fi
args=(--offline --mode rpc --no-session --no-extensions --no-skills --no-prompt-templates --no-themes)
for name in alpha beta gamma delta epsilon zeta; do args+=(--extension "$fixture/$name.ts"); done
cd "$fixture"
printf '%s\n' '{"id":"state","type":"get_state"}' '{"id":"ready","type":"get_commands"}' | env -i \
  PATH="$PATH" HOME="$root/home" TMPDIR="$root/tmp" PI_CODING_AGENT_DIR="$root/agent" \
  PI_OFFLINE=1 PI_TELEMETRY=0 PI_PERF_EXTENSION_TRACE="$root/imports.jsonl" \
  "$cli" "${args[@]}" > "$root/responses.jsonl" 2> "$root/stderr.log"
python3 - "$root" <<'PY'
import json
import sys
from pathlib import Path
root = Path(sys.argv[1])
names = ['alpha', 'beta', 'gamma', 'delta', 'epsilon', 'zeta']
responses = [json.loads(line) for line in (root / 'responses.jsonl').read_text().splitlines()]
assert len(responses) == 2 and all(response['success'] for response in responses)
assert [c['name'] for c in responses[1]['data']['commands'] if c['name'] in names] == names
trace = [json.loads(line) for line in (root / 'imports.jsonl').read_text().splitlines()]
assert sum(event['type'] == 'import:end' for event in trace) == 6
assert [event['name'] for event in trace if event['type'] == 'factory:end'] == names
print('PASS: actual standalone RPC, six imports, six ordered factories, two successful responses')
PY
