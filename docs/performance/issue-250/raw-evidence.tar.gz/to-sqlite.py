import json
from pathlib import Path
import sqlite3

root = Path(__file__).parent
output = root / 'analysis.sqlite'
if output.exists():
    raise RuntimeError(f'Refusing to overwrite {output}')
connection = sqlite3.connect(output)
connection.execute('CREATE TABLE attempts (dataset TEXT NOT NULL, ordinal INTEGER NOT NULL, body TEXT NOT NULL CHECK(json_valid(body)), PRIMARY KEY(dataset, ordinal))')
for dataset in ['baseline-profile', 'baseline-profile-valid', 'candidate-profile', 'matched']:
    records = json.loads((root / dataset / 'attempts.json').read_text())
    connection.executemany('INSERT INTO attempts VALUES (?, ?, ?)', [(dataset, index, json.dumps(record)) for index, record in enumerate(records)])
connection.executescript('''
CREATE VIEW measured AS
SELECT json_extract(body, '$.workload') AS workload,
       json_extract(body, '$.mode') AS mode,
       json_extract(body, '$.entry') AS entry,
       json_extract(body, '$.side') AS side,
       json_extract(body, '$.exit') AS exit,
       json_extract(body, '$.result.elapsedMs') AS ms,
       json_extract(body, '$.result.imports') AS imports,
       json_extract(body, '$.result.factories') AS factories
FROM attempts WHERE dataset='matched' AND json_extract(body, '$.warmup')=0;
''')
query = '''
WITH ordered AS (
    SELECT *, row_number() OVER (PARTITION BY workload, mode, entry, side ORDER BY ms) AS rank,
           count(*) OVER (PARTITION BY workload, mode, entry, side) AS n
    FROM measured
)
SELECT workload, mode, entry, side, max(n), min(ms), max(ms),
       avg(CASE WHEN rank IN ((n+1)/2, (n+2)/2) THEN ms END) AS median
FROM ordered GROUP BY workload, mode, entry, side ORDER BY workload, mode, entry, side;
'''
counts = connection.execute('SELECT count(*), sum(exit != 0), sum(imports), sum(factories) FROM measured').fetchone()
assert counts == (60, 0, 360, 360), counts
result = {'counts': {'measured': counts[0], 'failures': counts[1], 'imports': counts[2], 'factories': counts[3]},
          'medians': [dict(zip(['workload', 'mode', 'entry', 'side', 'n', 'minMs', 'maxMs', 'medianMs'], row)) for row in connection.execute(query)],
          'attemptSets': list(connection.execute("SELECT dataset, count(*), sum(json_extract(body, '$.exit') != 0) FROM attempts GROUP BY dataset"))}
connection.commit()
connection.close()
(root / 'sql-summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
