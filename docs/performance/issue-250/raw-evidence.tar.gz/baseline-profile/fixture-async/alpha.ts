import { appendFileSync } from "node:fs";
import { performance } from "node:perf_hooks";
import { Type } from "typebox";
const record = type => appendFileSync(process.env.PI_PERF_EXTENSION_TRACE, JSON.stringify({type, name: "alpha", at: performance.now()}) + "\n");
record("import:start");

await new Promise(resolve => setTimeout(resolve, 60));
record("import:end");
export default async function(pi) {
    record("factory:start");
    await new Promise(resolve => setTimeout(resolve, 2));
    pi.registerTool({name: "alpha", label: "alpha", description: "Synthetic tool", parameters: Type.Object({}), execute: async () => ({content: [{type: "text", text: "ok"}]})});
    pi.registerCommand("alpha", { handler: async () => {} });
    pi.registerFlag("first", {type: "string", default: "alpha"});
    record("factory:end");
}
