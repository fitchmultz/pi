import { appendFileSync } from "node:fs";
import { performance } from "node:perf_hooks";
import { Type } from "typebox";
const record = type => appendFileSync(process.env.PI_PERF_EXTENSION_TRACE, JSON.stringify({type, name: "beta", at: performance.now()}) + "\n");
record("import:start");

await new Promise(resolve => setTimeout(resolve, 50));
record("import:end");
export default async function(pi) {
    record("factory:start");
    await new Promise(resolve => setTimeout(resolve, 2));
    pi.registerTool({name: "beta", label: "beta", description: "Synthetic tool", parameters: Type.Object({}), execute: async () => ({content: [{type: "text", text: "ok"}]})});
    pi.registerCommand("beta", { handler: async () => {} });
    pi.registerFlag("first", {type: "string", default: "beta"});
    record("factory:end");
}
