import collections
import hashlib
import json
import os
from pathlib import Path
import platform
import re

base = Path(__file__).parent
profiles = []
for folder in ['baseline-profile-valid', 'candidate-profile']:
    attempts = json.loads((base / folder / 'attempts.json').read_text())
    for attempt in attempts:
        result = attempt['result']
        events = result['trace']
        active = peak = 0
        begins = {}
        durations = {'import': [], 'factory': []}
        for event in events:
            phase, action = event['type'].split(':')
            if action == 'start':
                begins[(phase, event['name'])] = event['at']
                if phase == 'import':
                    active += 1
                    peak = max(peak, active)
            else:
                durations[phase].append(event['at'] - begins[(phase, event['name'])])
                if phase == 'import':
                    active -= 1
        item = {key: attempt[key] for key in ['workload', 'mode', 'entry', 'side', 'run']}
        item.update({'peakImports': peak, 'sumImportEvaluationMs': sum(durations['import']),
                     'sumFactoryMs': sum(durations['factory']), 'elapsedMsInstrumented': result['elapsedMs'],
                     'jitiTranspileMessages': re.findall(r'\[transpile\].*', result['stderr']),
                     'startupTimings': result['stderr'][result['stderr'].find('--- Startup Timings'):] if '--- Startup Timings' in result['stderr'] else None})
        profiles.append(item)
    for path in sorted((base / folder).glob('**/*.cpuprofile')):
        data = json.loads(path.read_text())
        nodes = {node['id']: node for node in data['nodes']}
        weights = collections.Counter()
        for sample, delta in zip(data.get('samples', []), data.get('timeDeltas', [])):
            frame = nodes[sample]['callFrame']
            weights[(frame['functionName'], frame['url'])] += delta
        profiles.append({'profile': str(path.relative_to(base)), 'durationMs': (data['endTime'] - data['startTime']) / 1000,
                         'topSelfMs': [{'function': key[0], 'url': key[1], 'ms': value / 1000} for key, value in weights.most_common(12)]})
(base / 'profile-summary.json').write_text(json.dumps(profiles, indent=2))
metadata = {'platform': platform.platform(), 'cpus': os.cpu_count(), 'affinityCpus': len(os.sched_getaffinity(0)), 'roots': {}}
for side, root in [('before', Path('/workspace/pi-250-before')), ('after', Path('/workspace/pi-250'))]:
    files = ['package-lock.json', 'packages/coding-agent/package.json', 'packages/coding-agent/install-lock/package-lock.json',
             'packages/coding-agent/src/core/extensions/loader.ts', 'packages/coding-agent/dist/core/extensions/loader.js',
             'packages/coding-agent/dist/bundle/cli.js', 'packages/coding-agent/dist/bundle/rpc-entry.js',
             'packages/ai/src/providers/data/.manifest.json', 'node_modules/jiti/package.json', 'node_modules/jiti/dist/jiti.cjs',
             'node_modules/jiti/dist/babel.cjs']
    metadata['roots'][side] = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files if (root / name).is_file()}
(base / 'identity.json').write_text(json.dumps(metadata, indent=2))
print(json.dumps(metadata, indent=2))
